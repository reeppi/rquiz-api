## rquiz-api 
Esimerkki yksinkertaisen tietovisan node-apista. <br />
Käyttää mongodb:tä kysymysten ja pistetaulun tietokantana.<br />
<br/>
React-native : https://github.com/reeppi/rquiz (obsolete)<br />
Angular web-app:  https://tietovisa.netlify.app<br />
Avainsanat : Node, Express, Passport, Mongodb, Netlify. <br />
---------------------- <br />
tuomas.kokki@outlook.com