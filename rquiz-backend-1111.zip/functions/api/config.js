exports.config = { 
    dbUsername: "reeppi",
    dbPassword: "tpk210283",
    GoogleClientId:"433184759817-ffup1k13evu0b4p1i31nautouf6fhrv2.apps.googleusercontent.com",
    GoogleClientSecret:"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",
    FacebookClientId:"523085192774131",
    FacebookClientSecret:"cb6964ca2bdd2d2dda6c7158fb3410b2",
    SessionSecret:"TosiSalainen",
   // quizUrl:"http://localhost:4200"
    quizUrl:"https://tietovisa.netlify.app"
}